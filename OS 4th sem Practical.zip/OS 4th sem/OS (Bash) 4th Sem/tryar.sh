#!/usr/bin/bash
read a
res=$(( a**2 ))
printf "%d\n" $res
